<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = username = '$username' ,password = '$password';
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         session_register("username");
         $_SESSION['login_user'] = $username;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <title>Document</title>
</head>
<body>
    <div class="wrapper">
        <form class="login">
          <p class="title">Log in</p>
          <input type="text" placeholder="Username" name="usarname" autofocus/>
          <i class="fa fa-user"></i>
          <input type="password" placeholder="Password" name="password" />
          <i class="fa fa-key"></i>
          <a href="#">Forgot your password?</a>
          <button>
            <i class="spinner"></i>
            <span class="state">Log in</span>
          </button>
        </form>
        </p>
      </div>
</body>
</html>